export interface FrameStyle {
  id: string;
  name: string;
  description: string;
  basePrice: number;
  weight: number;
  style: 'board-track' | 'cruiser' | 'cafe-racer';
}

export interface EngineOption {
  id: string;
  name: string;
  type: '2-stroke' | '4-stroke' | 'electric';
  description: string;
  price: number;
  topSpeed: number;
  range: string;
  horsepower: string;
  soundFrequency: number; // Hz for synthesizer
}

export interface PaintOption {
  id: string;
  name: string;
  hex: string;
  price: number;
  type: 'matte' | 'metallic' | 'raw';
}

export interface TireOption {
  id: string;
  name: string;
  style: 'white-wall' | 'knobby' | 'thick-slick';
  price: number;
}

export interface AccessoryOption {
  id: string;
  name: string;
  description: string;
  price: number;
  category: 'lighting' | 'storage' | 'exhaust' | 'seat';
}

export interface BikeConfig {
  frame: FrameStyle;
  engine: EngineOption;
  paint: PaintOption;
  tire: TireOption;
  accessories: string[]; // Accessory IDs
}

export interface CommissionRequest {
  id: string;
  fullName: string;
  email: string;
  notes: string;
  config: BikeConfig;
  totalPrice: number;
  date: string;
  status: 'pending' | 'accepted' | 'under-construction' | 'completed';
}
