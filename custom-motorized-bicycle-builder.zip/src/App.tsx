import { useState, useEffect } from 'react';
import { BikeConfig } from './types';
import { PRESETS } from './data';
import BikePreview from './components/BikePreview';
import Customizer from './components/Customizer';
import Specs from './components/Specs';
import Garage from './components/Garage';
import ProcessTimeline from './components/ProcessTimeline';
import CommissionForm from './components/CommissionForm';
import { ChevronRight, Clipboard, Award, ShieldCheck, Instagram, Sliders, CheckSquare, Hammer, Layers, ListFilter } from 'lucide-react';

export default function App() {
  // Initialize with flagship build "The Spitfire V3"
  const [config, setConfig] = useState<BikeConfig>(PRESETS[0].config);
  
  // Audio engine state shared between engine controls & preview
  const [isEngineRunning, setIsEngineRunning] = useState(false);
  const [isRevving, setIsRevving] = useState(false);

  // Past submissions list loaded from localStorage
  const [savedCommissions, setSavedCommissions] = useState<any[]>([]);

  const loadSavedCommissions = () => {
    try {
      const saved = localStorage.getItem('ac_commissions');
      if (saved) {
        setSavedCommissions(JSON.parse(saved));
      }
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    loadSavedCommissions();
    
    // Listen for custom storage events to keep submissions updated
    const handleStorage = () => loadSavedCommissions();
    window.addEventListener('storage', handleStorage);
    // Interval check as backup
    const interval = setInterval(loadSavedCommissions, 2000);

    return () => {
      window.removeEventListener('storage', handleStorage);
      clearInterval(interval);
    };
  }, []);

  const handleSelectPreset = (presetConfig: BikeConfig) => {
    setConfig(presetConfig);
    // Stop engine sound if running to allow frequency reset
    setIsEngineRunning(false);
    setIsRevving(false);
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="w-full min-h-screen bg-stone-950 text-stone-100 font-sans flex flex-col overflow-x-hidden">
      {/* 1. TOP NAV BAR */}
      <nav className="h-20 border-b border-stone-800 flex items-center justify-between px-4 md:px-12 shrink-0 bg-stone-950/90 backdrop-blur sticky top-0 z-40">
        <div className="flex items-center space-x-3 cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
          <div className="w-10 h-10 bg-orange-600 flex items-center justify-center font-bold text-xl italic text-white font-mono select-none">
            AC
          </div>
          <span className="text-xl font-black tracking-tighter uppercase font-sans">
            Axel & Chain
          </span>
        </div>
        
        {/* Navigation items - anchors */}
        <div className="hidden md:flex space-x-8 text-xs font-bold uppercase tracking-widest text-stone-400">
          <button
            onClick={() => scrollToSection('workbench-viewport')}
            className="hover:text-white transition-colors cursor-pointer"
          >
            Workbench
          </button>
          <button
            onClick={() => scrollToSection('section-presets-garage')}
            className="hover:text-white transition-colors cursor-pointer"
          >
            Garage Blueprints
          </button>
          <button
            onClick={() => scrollToSection('section-process')}
            className="hover:text-white transition-colors cursor-pointer"
          >
            The Process
          </button>
        </div>

        <button
          onClick={() => scrollToSection('section-commission-form')}
          className="px-5 py-2.5 border border-stone-700 hover:bg-stone-100 hover:text-stone-950 hover:border-white transition-all text-xs font-bold uppercase tracking-wider cursor-pointer"
        >
          Commission a Build
        </button>
      </nav>

      {/* 2. DUAL COLUMN WORKBENCH & MAIN PRESENTATION */}
      <div id="workbench-viewport" className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        
        {/* LEFT COLUMN: HERO INFORMATION & ACTIVE STAGE PREVIEW */}
        <div className="w-full lg:w-[60%] lg:border-r border-stone-800 flex flex-col justify-between">
          
          {/* Header Taglines */}
          <div className="p-6 md:p-12 space-y-4">
            <div className="flex items-center space-x-2">
              <span className="inline-block bg-orange-600 text-[10px] px-2 py-1 font-bold uppercase tracking-[0.2em] text-white">
                FEATURED WORKSHOP: Austin, Texas
              </span>
              <span className="text-stone-600 font-mono text-[10px] hidden sm:inline">• EST. 2018</span>
            </div>

            <h1 className="text-5xl md:text-8xl font-black leading-[0.85] uppercase tracking-tighter text-white">
              Raw Iron & <br /> High Octane
            </h1>
            
            <p className="text-stone-400 text-sm md:text-base max-w-lg font-light leading-relaxed">
              We engineer custom, road-certified motorized bicycles. We seamlessly blend retro 1910s board-track racing ergonomics with modern high-scavenging powerplants and custom-tuned fuel mixtures.
            </p>
          </div>
          
          {/* Active interactive SVG Canvas / Graphic with rev panel */}
          <div className="flex-1 px-4 md:px-12 pb-6 md:pb-12 min-h-[350px] flex flex-col justify-end">
            <BikePreview
              config={config}
              isEngineRunning={isEngineRunning}
              setIsEngineRunning={setIsEngineRunning}
              isRevving={isRevving}
              setIsRevving={setIsRevving}
            />
          </div>
        </div>

        {/* RIGHT COLUMN: SPECS GRID & ACTIVE PART SELECTION sidebar */}
        <div className="w-full lg:w-[40%] flex flex-col bg-stone-950">
          {/* Top specifications dynamic grid */}
          <Specs config={config} />

          {/* Interactive part customizer tabs and accordions */}
          <div className="flex-1">
            <Customizer config={config} onChange={setConfig} />
          </div>
        </div>
      </div>

      {/* 3. SAVED COMMISSIONS SUMMARY DRAWER (Visible if user submitted previous configurations) */}
      {savedCommissions.length > 0 && (
        <div className="bg-stone-900 border-t border-stone-800 p-6 md:p-10">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center space-x-3 mb-6">
              <Clipboard size={18} className="text-orange-500" />
              <h3 className="text-lg font-black uppercase tracking-wider text-white">
                YOUR SUBMITTED COMMISSIONS ({savedCommissions.length})
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {savedCommissions.map((comm) => (
                <div
                  key={comm.id}
                  className="bg-stone-950 p-5 border border-stone-800 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-[10px] font-mono text-orange-500 font-bold">{comm.id}</span>
                      <span className="text-[10px] font-mono text-stone-500">{comm.date}</span>
                    </div>
                    <div className="text-sm font-black uppercase text-stone-100 mb-2">
                      {comm.config.frame.name}
                    </div>
                    <div className="text-xs text-stone-400 font-mono space-y-1">
                      <div>Drivetrain: {comm.config.engine.name}</div>
                      <div>Finish: {comm.config.paint.name}</div>
                      <div>Value: ${comm.totalPrice.toLocaleString()}</div>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-stone-900 flex justify-between items-center">
                    <span className="text-[9px] font-mono uppercase bg-orange-600/10 text-orange-500 px-2 py-0.5 border border-orange-500/20 font-bold">
                      IN QUEUE / VERIFYING
                    </span>
                    <button
                      onClick={() => handleSelectPreset(comm.config)}
                      className="text-[10px] font-mono text-stone-400 hover:text-white transition-colors underline"
                    >
                      Reload to Bench
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 4. PRESETS BLUEPRINTS GALLERY (THE GARAGE) */}
      <div id="section-presets-garage">
        <Garage onSelectPreset={handleSelectPreset} currentConfig={config} />
      </div>

      {/* 5. ROAD TESTING AND FABRICATION CHRONICLE */}
      <div id="section-process">
        <ProcessTimeline />
      </div>

      {/* 6. ORDER FORM PORTAL WITH SPEC RECEIPT */}
      <CommissionForm config={config} />

      {/* 7. FOOTER */}
      <footer className="h-20 border-t border-stone-800 flex flex-col sm:flex-row items-center justify-between px-6 md:px-12 shrink-0 bg-stone-950 text-xs text-stone-500 font-mono">
        <div className="flex space-x-6 mb-3 sm:mb-0">
          <a href="#" className="hover:text-stone-300 transition-colors flex items-center space-x-1">
            <Instagram size={12} />
            <span>@AXELANDCHAIN</span>
          </a>
          <span>•</span>
          <span>WORKSHOP DOCS</span>
        </div>
        <div className="text-[10px] text-stone-600 font-mono italic text-center sm:text-right">
          EST. 2018 // AUSTIN, TEXAS // BUILT WITH INTENT
        </div>
      </footer>
    </div>
  );
}
