import React, { useState } from 'react';
import { BikeConfig, CommissionRequest } from '../types';
import { ACCESSORIES } from '../data';
import { Calendar, CheckCircle2, Clipboard, Printer, Send, Sparkles } from 'lucide-react';

interface CommissionFormProps {
  config: BikeConfig;
}

export default function CommissionForm({ config }: CommissionFormProps) {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [notes, setNotes] = useState('');
  const [submittedRequest, setSubmittedRequest] = useState<CommissionRequest | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Calculate prices
  const framePrice = config.frame.basePrice;
  const enginePrice = config.engine.price;
  const paintPrice = config.paint.price;
  const tirePrice = config.tire.price;
  const accessoriesPrice = config.accessories.reduce((sum, id) => {
    const acc = ACCESSORIES.find((a) => a.id === id);
    return sum + (acc ? acc.price : 0);
  }, 0);

  const totalPrice = framePrice + enginePrice + paintPrice + tirePrice + accessoriesPrice;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !email) return;

    setIsSubmitting(true);

    // Simulate submission delays
    setTimeout(() => {
      const serialNum = `AC-2026-${Math.floor(1000 + Math.random() * 9000)}`;
      const request: CommissionRequest = {
        id: serialNum,
        fullName,
        email,
        notes,
        config,
        totalPrice,
        date: new Date().toLocaleDateString('en-US', {
          year: 'numeric',
          month: 'long',
          day: 'numeric',
        }),
        status: 'pending',
      };

      // Save to local storage for user's order history
      const existing = localStorage.getItem('ac_commissions');
      const commissions = existing ? JSON.parse(existing) : [];
      commissions.push(request);
      localStorage.setItem('ac_commissions', JSON.stringify(commissions));

      setSubmittedRequest(request);
      setIsSubmitting(false);

      // Scroll to ticket receipt
      setTimeout(() => {
        const ticketEl = document.getElementById('commission-receipt-ticket');
        if (ticketEl) ticketEl.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    }, 1200);
  };

  const printTicket = () => {
    window.print();
  };

  return (
    <div id="section-commission-form" className="bg-stone-950 p-6 md:p-12 border-t border-stone-800 relative">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-10">
          <span className="text-[10px] font-bold text-orange-600 uppercase tracking-widest block mb-2">
            COMMISSION A CUSTOM BUILD
          </span>
          <h2 className="text-4xl font-black uppercase tracking-tighter text-stone-100">
            START YOUR BUILD COMMISSION
          </h2>
          <p className="text-stone-400 text-xs font-mono max-w-lg mx-auto mt-3 leading-relaxed">
            INPUT YOUR DETAILS TO SUBMIT YOUR BENCH LAYOUT DIRECTLY TO THE AUSTIN WORKSHOP. NO DEPOSIT IS CHARGED UNTIL MANUAL SCHEMATIC CONFIRMATION.
          </p>
        </div>

        {!submittedRequest ? (
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-8 bg-stone-900/30 p-6 md:p-10 border border-stone-800">
            {/* Left Hand: Specifications Checkoff */}
            <div className="space-y-6 md:border-r md:border-stone-800 md:pr-8">
              <h3 className="text-sm font-bold uppercase tracking-wider text-orange-500 font-mono">
                CURRENT WORKBENCH REVIEW
              </h3>
              
              <div className="space-y-3 divide-y divide-stone-800/60 text-xs">
                <div className="flex justify-between py-2">
                  <span className="text-stone-500 uppercase font-mono">01. CHASSIS STYLE</span>
                  <span className="font-bold text-stone-200">{config.frame.name} (${config.frame.basePrice})</span>
                </div>
                <div className="flex justify-between py-2">
                  <span className="text-stone-500 uppercase font-mono">02. DRIVETRAIN</span>
                  <span className="font-bold text-stone-200">{config.engine.name} (${config.engine.price})</span>
                </div>
                <div className="flex justify-between py-2">
                  <span className="text-stone-500 uppercase font-mono">03. COAT FINISH</span>
                  <span className="font-bold text-stone-200">{config.paint.name} (${config.paint.price})</span>
                </div>
                <div className="flex justify-between py-2">
                  <span className="text-stone-500 uppercase font-mono">04. TYRES</span>
                  <span className="font-bold text-stone-200">{config.tire.name} (${config.tire.price})</span>
                </div>
                {config.accessories.length > 0 && (
                  <div className="py-2">
                    <span className="text-stone-500 uppercase font-mono block mb-1">05. ACCESSORIES EQUIP</span>
                    <ul className="space-y-1 pl-3 border-l border-orange-600/50">
                      {config.accessories.map((id) => {
                        const acc = ACCESSORIES.find((a) => a.id === id);
                        return acc ? (
                          <li key={id} className="font-medium text-stone-300 flex justify-between">
                            <span>• {acc.name}</span>
                            <span>+${acc.price}</span>
                          </li>
                        ) : null;
                      })}
                    </ul>
                  </div>
                )}
              </div>

              <div className="pt-4 border-t border-stone-800 flex justify-between items-end">
                <div>
                  <div className="text-[10px] text-stone-500 uppercase font-mono">ESTIMATED TOTAL OUT</div>
                  <div className="text-2xl font-black text-orange-500 font-mono">${totalPrice.toLocaleString()}</div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] text-stone-500 uppercase font-mono">ATX SALES TAXES</div>
                  <div className="text-xs font-mono text-stone-400">INCLUDED IN BASE</div>
                </div>
              </div>
            </div>

            {/* Right Hand: Client Contact Intake */}
            <div className="flex flex-col justify-between space-y-6">
              <div className="space-y-4">
                <h3 className="text-sm font-bold uppercase tracking-wider text-orange-500 font-mono">
                  CONTACT DETAILS
                </h3>

                <div className="space-y-3">
                  <div>
                    <label className="block text-[10px] font-mono text-stone-400 uppercase tracking-widest mb-1">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="e.g. Samuel Maverick"
                      id="input-fullname"
                      className="w-full bg-stone-950 border border-stone-800 p-3 text-stone-100 text-xs focus:border-orange-500 outline-none transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-mono text-stone-400 uppercase tracking-widest mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="e.g. sam@austinmail.com"
                      id="input-email"
                      className="w-full bg-stone-950 border border-stone-800 p-3 text-stone-100 text-xs focus:border-orange-500 outline-none transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-mono text-stone-400 uppercase tracking-widest mb-1">
                      Custom Engineering Notes (Optional)
                    </label>
                    <textarea
                      rows={4}
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="Request custom frame sizes, alternate tire brands, specialized tank logos, or high performance jets..."
                      id="input-notes"
                      className="w-full bg-stone-950 border border-stone-800 p-3 text-stone-100 text-xs focus:border-orange-500 outline-none transition-colors resize-none"
                    />
                  </div>
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                id="btn-submit-commission"
                className="w-full py-4 bg-orange-600 hover:bg-orange-700 disabled:bg-stone-800 disabled:border-stone-700 disabled:text-stone-500 border border-orange-500 text-white font-mono text-xs font-bold uppercase tracking-widest transition-all duration-300 flex items-center justify-center space-x-3 cursor-pointer"
              >
                {isSubmitting ? (
                  <>
                    <span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>TRANSMITTING BLUEPRINT...</span>
                  </>
                ) : (
                  <>
                    <Send size={12} />
                    <span>SUBMIT SPECIFICATIONS SHEET</span>
                  </>
                )}
              </button>
            </div>
          </form>
        ) : (
          /* MAGNIFICENT BLUEPRINT TICKET ON SUCCESS */
          <div id="commission-receipt-ticket" className="bg-stone-900 border border-orange-600 p-6 md:p-10 relative overflow-hidden max-w-2xl mx-auto shadow-[0_15px_30px_rgba(0,0,0,0.8)]">
            {/* Stamp Detail */}
            <div className="absolute right-6 top-6 border-4 border-dashed border-orange-600 px-3 py-1.5 transform rotate-6 text-[10px] font-black text-orange-500 font-mono tracking-[0.2em] uppercase select-none">
              A&C APPROVED
            </div>

            <div className="flex items-center space-x-3 mb-6">
              <CheckCircle2 size={24} className="text-orange-500" />
              <div>
                <h3 className="text-lg font-black text-stone-100 uppercase tracking-tight">COMMISSION RECEIVED</h3>
                <p className="text-[10px] text-stone-400 font-mono uppercase">TICKET CODE: {submittedRequest.id}</p>
              </div>
            </div>

            {/* Technical Specification Table */}
            <div className="border border-stone-800 bg-stone-950 p-6 font-mono text-xs space-y-4 mb-6">
              <div className="flex justify-between border-b border-stone-800 pb-2">
                <span className="text-stone-500">BUILD SERIAL:</span>
                <span className="text-orange-500 font-bold">{submittedRequest.id}</span>
              </div>
              <div className="flex justify-between border-b border-stone-800 pb-2">
                <span className="text-stone-500">CLIENT NAME:</span>
                <span className="text-stone-300 font-bold uppercase">{submittedRequest.fullName}</span>
              </div>
              <div className="flex justify-between border-b border-stone-800 pb-2">
                <span className="text-stone-500">CLIENT EMAIL:</span>
                <span className="text-stone-300 font-medium">{submittedRequest.email}</span>
              </div>
              <div className="flex justify-between border-b border-stone-800 pb-2">
                <span className="text-stone-500">SUBMISSION DATE:</span>
                <span className="text-stone-300">{submittedRequest.date}</span>
              </div>

              {/* Specs detailed section */}
              <div className="pt-2">
                <span className="text-stone-500 block mb-2">FABRICATION CHECKLIST:</span>
                <div className="space-y-1.5 pl-3 border-l-2 border-stone-800">
                  <div className="flex justify-between text-stone-400">
                    <span>Frame: {submittedRequest.config.frame.name}</span>
                    <span>${submittedRequest.config.frame.basePrice}</span>
                  </div>
                  <div className="flex justify-between text-stone-400">
                    <span>Engine: {submittedRequest.config.engine.name}</span>
                    <span>${submittedRequest.config.engine.price}</span>
                  </div>
                  <div className="flex justify-between text-stone-400">
                    <span>Coat: {submittedRequest.config.paint.name}</span>
                    <span>${submittedRequest.config.paint.price}</span>
                  </div>
                  <div className="flex justify-between text-stone-400">
                    <span>Tyres: {submittedRequest.config.tire.name}</span>
                    <span>${submittedRequest.config.tire.price}</span>
                  </div>
                  {submittedRequest.config.accessories.map((accId) => {
                    const foundAcc = ACCESSORIES.find(a => a.id === accId);
                    return foundAcc ? (
                      <div key={accId} className="flex justify-between text-stone-400">
                        <span>• Addon: {foundAcc.name}</span>
                        <span>${foundAcc.price}</span>
                      </div>
                    ) : null;
                  })}
                </div>
              </div>

              {submittedRequest.notes && (
                <div className="border-t border-stone-800 pt-4">
                  <span className="text-stone-500 block mb-1">ENGINEER NOTES:</span>
                  <p className="text-stone-400 text-[11px] leading-relaxed italic">
                    "{submittedRequest.notes}"
                  </p>
                </div>
              )}

              <div className="border-t border-stone-800 pt-4 flex justify-between items-baseline">
                <span className="text-stone-300 font-bold">TOTAL PRICE OUT:</span>
                <span className="text-xl font-black text-orange-500">${submittedRequest.totalPrice.toLocaleString()}</span>
              </div>
            </div>

            <p className="text-[10px] text-stone-400 font-mono text-center leading-relaxed mb-6">
              OUR ATX TEAM WILL VERIFY FITMENT WITHIN 24 BUSINESS HOURS AND DISPATCH AN INVOICE SCHEMATIC BLUEPRINT TO YOUR EMAIL ADDRESS. THANK YOU FOR CO-DESIGNING WITH US.
            </p>

            {/* Action options */}
            <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3">
              <button
                onClick={() => setSubmittedRequest(null)}
                id="btn-another-build"
                className="flex-1 py-3 bg-stone-950 hover:bg-stone-800 border border-stone-800 text-stone-300 font-mono text-xs font-bold uppercase tracking-wider text-center transition-all"
              >
                CONFIG ANOTHER BUILD
              </button>
              <button
                onClick={printTicket}
                id="btn-print-receipt"
                className="flex-1 py-3 bg-orange-600 hover:bg-orange-700 border border-orange-500 text-white font-mono text-xs font-bold uppercase tracking-wider flex items-center justify-center space-x-2 transition-all"
              >
                <Printer size={12} />
                <span>PRINT SPECS SHEET</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
