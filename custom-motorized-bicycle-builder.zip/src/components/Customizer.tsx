import { useState } from 'react';
import { FRAMES, ENGINES, PAINTS, TIRES, ACCESSORIES } from '../data';
import { BikeConfig, FrameStyle, EngineOption, PaintOption, TireOption } from '../types';
import { ChevronRight, Settings2, ShieldCheck, HelpCircle } from 'lucide-react';

interface CustomizerProps {
  config: BikeConfig;
  onChange: (newConfig: BikeConfig) => void;
}

type TabType = 'frame' | 'engine' | 'paint' | 'tire' | 'accessories';

export default function Customizer({ config, onChange }: CustomizerProps) {
  const [activeTab, setActiveTab] = useState<TabType>('frame');

  const selectFrame = (frame: FrameStyle) => {
    onChange({ ...config, frame });
  };

  const selectEngine = (engine: EngineOption) => {
    // If selecting electric, filter out "exhaust-chamber" accessory which is 2-stroke only
    let updatedAccessories = [...config.accessories];
    if (engine.type === 'electric') {
      updatedAccessories = updatedAccessories.filter(id => id !== 'exhaust-chamber');
    }
    onChange({ ...config, engine, accessories: updatedAccessories });
  };

  const selectPaint = (paint: PaintOption) => {
    onChange({ ...config, paint });
  };

  const selectTire = (tire: TireOption) => {
    onChange({ ...config, tire });
  };

  const toggleAccessory = (id: string) => {
    // 2-stroke exhaust constraint
    if (id === 'exhaust-chamber' && config.engine.type === 'electric') {
      return;
    }

    const accessories = config.accessories.includes(id)
      ? config.accessories.filter((a) => a !== id)
      : [...config.accessories, id];
    onChange({ ...config, accessories });
  };

  const tabs: { id: TabType; label: string; num: string }[] = [
    { id: 'frame', label: 'CHASSIS', num: '01' },
    { id: 'engine', label: 'DRIVETRAIN', num: '02' },
    { id: 'paint', label: 'FINISH', num: '03' },
    { id: 'tire', label: 'TYRES', num: '04' },
    { id: 'accessories', label: 'ACCESSORIES', num: '05' },
  ];

  return (
    <div className="flex flex-col h-full bg-stone-950 border-t lg:border-t-0 border-stone-800">
      {/* Category Selection Tabs (Geometric segment bar) */}
      <div className="flex border-b border-stone-800 overflow-x-auto scrollbar-none">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            id={`tab-select-${tab.id}`}
            className={`flex-1 py-4 px-3 text-center border-r last:border-r-0 border-stone-800 shrink-0 font-mono text-[10px] font-black uppercase tracking-wider transition-all relative ${
              activeTab === tab.id
                ? 'bg-stone-900 text-orange-500'
                : 'text-stone-400 hover:text-white hover:bg-stone-900/40'
            }`}
          >
            <span className="block text-[8px] opacity-40 font-normal mb-0.5">{tab.num}</span>
            {tab.label}
            {activeTab === tab.id && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-orange-600" />
            )}
          </button>
        ))}
      </div>

      {/* Choice Panel Area */}
      <div className="flex-1 p-6 overflow-y-auto max-h-[380px] lg:max-h-[500px]">
        {/* 1. CHASSIS (FRAMES) */}
        {activeTab === 'frame' && (
          <div className="space-y-4">
            <div className="flex items-center space-x-2 text-[10px] font-mono tracking-widest text-stone-500 uppercase">
              <Settings2 size={12} />
              <span>Select Chassis profile</span>
            </div>
            <div className="space-y-3">
              {FRAMES.map((f) => {
                const isSelected = config.frame.id === f.id;
                return (
                  <button
                    key={f.id}
                    onClick={() => selectFrame(f)}
                    id={`option-frame-${f.id}`}
                    className={`w-full text-left p-4 border transition-all relative group flex flex-col justify-between ${
                      isSelected
                        ? 'border-orange-500 bg-stone-900'
                        : 'border-stone-800 bg-stone-950 hover:border-stone-700'
                    }`}
                  >
                    <div className="flex justify-between items-start w-full">
                      <span className={`text-xs font-black uppercase tracking-wide ${isSelected ? 'text-orange-500' : 'text-stone-100'}`}>
                        {f.name}
                      </span>
                      <span className="text-xs font-mono text-stone-400 font-bold">
                        ${f.basePrice}
                      </span>
                    </div>
                    <p className="text-xs text-stone-400 mt-2 font-light leading-relaxed">
                      {f.description}
                    </p>
                    <div className="mt-3 flex space-x-4 text-[9px] font-mono text-stone-500 uppercase">
                      <span>WEIGHT: {f.weight} lbs</span>
                      <span>•</span>
                      <span>Double Triangle Weld</span>
                    </div>
                    {isSelected && (
                      <span className="absolute right-0 top-0 w-1.5 h-1.5 bg-orange-600" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* 2. DRIVETRAIN (ENGINES) */}
        {activeTab === 'engine' && (
          <div className="space-y-4">
            <div className="flex items-center space-x-2 text-[10px] font-mono tracking-widest text-stone-500 uppercase">
              <Settings2 size={12} />
              <span>Select powerplant</span>
            </div>
            <div className="space-y-3">
              {ENGINES.map((e) => {
                const isSelected = config.engine.id === e.id;
                return (
                  <button
                    key={e.id}
                    onClick={() => selectEngine(e)}
                    id={`option-engine-${e.id}`}
                    className={`w-full text-left p-4 border transition-all relative group flex flex-col justify-between ${
                      isSelected
                        ? 'border-orange-500 bg-stone-900'
                        : 'border-stone-800 bg-stone-950 hover:border-stone-700'
                    }`}
                  >
                    <div className="flex justify-between items-start w-full">
                      <div className="flex flex-col">
                        <span className={`text-xs font-black uppercase tracking-wide ${isSelected ? 'text-orange-500' : 'text-stone-100'}`}>
                          {e.name}
                        </span>
                        <span className="text-[9px] font-mono text-orange-500/80 font-bold tracking-widest uppercase mt-0.5">
                          {e.type} System
                        </span>
                      </div>
                      <span className="text-xs font-mono text-stone-400 font-bold">
                        ${e.price}
                      </span>
                    </div>
                    <p className="text-xs text-stone-400 mt-2 font-light leading-relaxed">
                      {e.description}
                    </p>
                    <div className="mt-3 grid grid-cols-3 gap-2 text-[9px] font-mono text-stone-500 uppercase border-t border-stone-800/40 pt-2">
                      <div>SPEED: {e.topSpeed} MPH</div>
                      <div>RANGE: {e.range}</div>
                      <div>POWER: {e.horsepower}</div>
                    </div>
                    {isSelected && (
                      <span className="absolute right-0 top-0 w-1.5 h-1.5 bg-orange-600" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* 3. FINISH (PAINT) */}
        {activeTab === 'paint' && (
          <div className="space-y-4">
            <div className="flex items-center space-x-2 text-[10px] font-mono tracking-widest text-stone-500 uppercase">
              <Settings2 size={12} />
              <span>Select Frame Coat finish</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {PAINTS.map((p) => {
                const isSelected = config.paint.id === p.id;
                return (
                  <button
                    key={p.id}
                    onClick={() => selectPaint(p)}
                    id={`option-paint-${p.id}`}
                    className={`text-left p-3 border transition-all relative flex flex-col justify-between ${
                      isSelected
                        ? 'border-orange-500 bg-stone-900'
                        : 'border-stone-800 bg-stone-950 hover:border-stone-700'
                    }`}
                  >
                    <div className="flex items-center space-x-3 mb-2">
                      <span
                        className="w-6 h-6 rounded-none border border-stone-700 block shrink-0"
                        style={{ backgroundColor: p.hex }}
                      />
                      <div className="flex flex-col">
                        <span className="text-xs font-black uppercase tracking-tight text-white">
                          {p.name}
                        </span>
                        <span className="text-[9px] font-mono text-stone-500 uppercase">
                          {p.type}
                        </span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center text-[10px] font-mono text-stone-400">
                      <span>Premium finish</span>
                      <span className="font-bold">+${p.price}</span>
                    </div>
                    {isSelected && (
                      <span className="absolute right-0 top-0 w-1.5 h-1.5 bg-orange-600" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* 4. TYRES */}
        {activeTab === 'tire' && (
          <div className="space-y-4">
            <div className="flex items-center space-x-2 text-[10px] font-mono tracking-widest text-stone-500 uppercase">
              <Settings2 size={12} />
              <span>Select High performance rubber</span>
            </div>
            <div className="space-y-3">
              {TIRES.map((t) => {
                const isSelected = config.tire.id === t.id;
                return (
                  <button
                    key={t.id}
                    onClick={() => selectTire(t)}
                    id={`option-tire-${t.id}`}
                    className={`w-full text-left p-4 border transition-all relative flex items-center justify-between ${
                      isSelected
                        ? 'border-orange-500 bg-stone-900'
                        : 'border-stone-800 bg-stone-950 hover:border-stone-700'
                    }`}
                  >
                    <div className="flex flex-col">
                      <span className={`text-xs font-black uppercase tracking-wide ${isSelected ? 'text-orange-500' : 'text-stone-100'}`}>
                        {t.name}
                      </span>
                      <span className="text-[9px] font-mono text-stone-500 uppercase mt-1">
                        High durability compound
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="text-xs font-mono text-stone-300 font-bold">
                        ${t.price}
                      </span>
                    </div>
                    {isSelected && (
                      <span className="absolute right-0 top-0 w-1.5 h-1.5 bg-orange-600" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* 5. ACCESSORIES */}
        {activeTab === 'accessories' && (
          <div className="space-y-4">
            <div className="flex items-center space-x-2 text-[10px] font-mono tracking-widest text-stone-500 uppercase">
              <Settings2 size={12} />
              <span>Equip custom components</span>
            </div>
            <div className="space-y-3">
              {ACCESSORIES.map((acc) => {
                const isSelected = config.accessories.includes(acc.id);
                const isGasOnly = acc.id === 'exhaust-chamber';
                const isDisabled = isGasOnly && config.engine.type === 'electric';

                return (
                  <button
                    key={acc.id}
                    disabled={isDisabled}
                    onClick={() => toggleAccessory(acc.id)}
                    id={`option-accessory-${acc.id}`}
                    className={`w-full text-left p-4 border transition-all relative flex flex-col justify-between ${
                      isDisabled
                        ? 'opacity-30 cursor-not-allowed border-stone-900 bg-stone-950/20'
                        : isSelected
                        ? 'border-orange-500 bg-stone-900'
                        : 'border-stone-800 bg-stone-950 hover:border-stone-700'
                    }`}
                  >
                    <div className="flex justify-between items-start w-full">
                      <div className="flex items-center space-x-3">
                        <div className={`w-4 h-4 border flex items-center justify-center shrink-0 ${isSelected ? 'border-orange-500 bg-orange-600 text-white' : 'border-stone-700'}`}>
                          {isSelected && (
                            <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" />
                            </svg>
                          )}
                        </div>
                        <span className={`text-xs font-black uppercase tracking-wide ${isSelected ? 'text-orange-500' : 'text-stone-100'}`}>
                          {acc.name}
                        </span>
                      </div>
                      <span className="text-xs font-mono text-stone-400 font-bold">
                        +${acc.price}
                      </span>
                    </div>
                    <p className="text-xs text-stone-400 mt-2 pl-7 font-light leading-relaxed">
                      {acc.description}
                    </p>
                    {isGasOnly && (
                      <span className="text-[8px] font-mono text-orange-500 mt-1 pl-7 block">
                        * Required: Gas Engine (2-Stroke only)
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Guide Note Box */}
      <div className="p-4 border-t border-stone-800 bg-stone-950 flex items-start space-x-3">
        <ShieldCheck size={16} className="text-orange-500 shrink-0 mt-0.5" />
        <p className="text-[10px] text-stone-400 leading-relaxed font-mono">
          EACH AXEL & CHAIN BUILD MEETS STRINGENT TESTING AND SHIPMENT COMPLIANCE. WE CRATE AND SHIP NATIONWIDE. ESTIMATES INCLUDE CRATING.
        </p>
      </div>
    </div>
  );
}
