import { BikeConfig } from '../types';
import { ACCESSORIES } from '../data';
import { Gauge, Sparkles, DollarSign, Calendar, Flame, Weight } from 'lucide-react';

interface SpecsProps {
  config: BikeConfig;
}

export default function Specs({ config }: SpecsProps) {
  // Calculations
  const framePrice = config.frame.basePrice;
  const enginePrice = config.engine.price;
  const paintPrice = config.paint.price;
  const tirePrice = config.tire.price;
  const accessoriesPrice = config.accessories.reduce((sum, id) => {
    const acc = ACCESSORIES.find((a) => a.id === id);
    return sum + (acc ? acc.price : 0);
  }, 0);

  const totalPrice = framePrice + enginePrice + paintPrice + tirePrice + accessoriesPrice;

  // Weight Calculation (approximate)
  const engineWeight = config.engine.type === '2-stroke' ? 12 : config.engine.type === '4-stroke' ? 18 : 22; // electric batteries are heavy
  const tireWeight = config.tire.style === 'white-wall' ? 4 : config.tire.style === 'knobby' ? 5 : 3.5;
  const accessoriesWeight = config.accessories.length * 1.5;
  const totalWeight = config.frame.weight + engineWeight + tireWeight + accessoriesWeight;

  // Estimated build duration
  const baseBuildDays = 14;
  const paintDelay = config.paint.type === 'metallic' ? 5 : 3;
  const accessoryDelay = config.accessories.length * 2;
  const totalBuildDays = baseBuildDays + paintDelay + accessoryDelay;

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-px bg-stone-800 border-b border-t md:border-t-0 border-stone-800">
      {/* 1. SPEED */}
      <div className="bg-stone-950 p-6 flex flex-col justify-between">
        <div className="flex items-center space-x-2 text-orange-500 mb-4">
          <Gauge size={14} />
          <span className="text-[10px] font-bold uppercase tracking-widest">TOP VELOCITY</span>
        </div>
        <div>
          <div className="text-3xl md:text-4xl font-black italic text-stone-100 font-mono">
            {config.engine.topSpeed} MPH
          </div>
          <div className="text-xs text-stone-500 font-mono mt-1">Governor Limited</div>
        </div>
      </div>

      {/* 2. RANGE */}
      <div className="bg-stone-950 p-6 flex flex-col justify-between">
        <div className="flex items-center space-x-2 text-orange-500 mb-4">
          <Flame size={14} />
          <span className="text-[10px] font-bold uppercase tracking-widest">FUEL RANGE</span>
        </div>
        <div>
          <div className="text-3xl md:text-4xl font-black italic text-stone-100 font-mono">
            {config.engine.range}
          </div>
          <div className="text-xs text-stone-500 font-mono mt-1">
            {config.engine.type === 'electric' ? 'Per Full Charge' : 'Tank Capacity: 1.5 Gal'}
          </div>
        </div>
      </div>

      {/* 3. HORSEPOWER */}
      <div className="bg-stone-950 p-6 flex flex-col justify-between">
        <div className="flex items-center space-x-2 text-orange-500 mb-4">
          <Sparkles size={14} />
          <span className="text-[10px] font-bold uppercase tracking-widest">POWER OUTPUT</span>
        </div>
        <div>
          <div className="text-3xl md:text-4xl font-black italic text-stone-100 font-mono">
            {config.engine.horsepower}
          </div>
          <div className="text-xs text-stone-500 font-mono mt-1">
            {config.engine.type === 'electric' ? 'Brushless Hub' : 'Balanced Engine Mount'}
          </div>
        </div>
      </div>

      {/* 4. WEIGHT */}
      <div className="bg-stone-950 p-6 flex flex-col justify-between">
        <div className="flex items-center space-x-2 text-orange-500 mb-4">
          <Weight size={14} />
          <span className="text-[10px] font-bold uppercase tracking-widest">BUILD WEIGHT</span>
        </div>
        <div>
          <div className="text-3xl md:text-4xl font-black italic text-stone-100 font-mono">
            {totalWeight.toFixed(1)} LBS
          </div>
          <div className="text-xs text-stone-500 font-mono mt-1">Ready-to-ride weight</div>
        </div>
      </div>

      {/* 5. BUILD TIMELINE */}
      <div className="bg-stone-950 p-6 flex flex-col justify-between">
        <div className="flex items-center space-x-2 text-orange-500 mb-4">
          <Calendar size={14} />
          <span className="text-[10px] font-bold uppercase tracking-widest">ESTIMATED LEAD</span>
        </div>
        <div>
          <div className="text-3xl md:text-4xl font-black italic text-stone-100 font-mono">
            {Math.ceil(totalBuildDays / 7)} WEEKS
          </div>
          <div className="text-xs text-stone-500 font-mono mt-1">
            Hand-built to order in ATX
          </div>
        </div>
      </div>

      {/* 6. TOTAL COMMISSION COST */}
      <div className="bg-stone-950 p-6 flex flex-col justify-between col-span-2 md:col-span-1">
        <div className="flex items-center space-x-2 text-orange-500 mb-4">
          <DollarSign size={14} />
          <span className="text-[10px] font-bold uppercase tracking-widest">ESTIMATED TOTAL</span>
        </div>
        <div>
          <div className="text-3xl md:text-4xl font-black text-orange-500 font-mono">
            ${totalPrice.toLocaleString()}
          </div>
          <button
            onClick={() => {
              const el = document.getElementById('section-commission-form');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            id="btn-goto-order"
            className="text-[10px] text-stone-400 font-mono hover:text-white transition-colors underline decoration-orange-600 block mt-1 uppercase text-left"
          >
            Commission build
          </button>
        </div>
      </div>
    </div>
  );
}
