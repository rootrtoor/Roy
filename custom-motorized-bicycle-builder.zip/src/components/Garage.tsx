import { BikeConfig } from '../types';
import { PRESETS } from '../data';
import { Sparkles, ArrowUpRight } from 'lucide-react';

interface GarageProps {
  onSelectPreset: (config: BikeConfig) => void;
  currentConfig: BikeConfig;
}

export default function Garage({ onSelectPreset, currentConfig }: GarageProps) {
  return (
    <div className="bg-stone-950 p-6 md:p-10 border-t border-stone-800">
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-8">
        <div>
          <span className="text-[10px] font-bold text-orange-600 uppercase tracking-widest block mb-2">
            CURATED BLUEPRINTS
          </span>
          <h2 className="text-3xl font-black uppercase tracking-tighter text-stone-100">
            THE GARAGE PRESETS
          </h2>
        </div>
        <p className="text-stone-400 text-xs font-mono max-w-sm mt-3 md:mt-0 leading-relaxed">
          LOAD ONE OF OUR PRE-CONFIGURED ARCHETYPE BUILDS INTO THE ACTIVE WORKBENCH TO BEGIN CUSTOMIZING FROM A PROVEN FOUNDATION.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {PRESETS.map((preset) => {
          // Calculate individual price
          const framePrice = preset.config.frame.basePrice;
          const enginePrice = preset.config.engine.price;
          const paintPrice = preset.config.paint.price;
          const tirePrice = preset.config.tire.price;
          const accPrice = preset.config.accessories.reduce((sum, id) => {
            const price = 100; // default backup
            return sum + price; // simplified for quick display in garage card
          }, 0);
          const total = framePrice + enginePrice + paintPrice + tirePrice + (preset.config.accessories.length * 120);

          return (
            <div
              key={preset.id}
              className="border border-stone-800 bg-stone-900/50 p-6 flex flex-col justify-between hover:border-stone-700 transition-all group relative"
            >
              <div>
                <div className="flex justify-between items-center mb-3">
                  <span className="text-[9px] font-mono text-orange-500 font-bold tracking-widest uppercase">
                    {preset.serial}
                  </span>
                  <span className="text-xs font-mono text-stone-400 font-bold">
                    Est. ${total.toLocaleString()}
                  </span>
                </div>
                
                <h3 className="text-lg font-black text-white uppercase tracking-tight mb-2 group-hover:text-orange-500 transition-colors">
                  {preset.name}
                </h3>
                
                <p className="text-xs text-stone-400 font-light leading-relaxed mb-4">
                  {preset.description}
                </p>

                {/* Spec summary pills */}
                <div className="flex flex-wrap gap-1.5 mb-6">
                  <span className="text-[9px] font-mono uppercase bg-stone-950 text-stone-300 px-2 py-0.5 border border-stone-800">
                    {preset.config.frame.name.split(' ')[0]}
                  </span>
                  <span className="text-[9px] font-mono uppercase bg-stone-950 text-stone-300 px-2 py-0.5 border border-stone-800">
                    {preset.config.engine.type}
                  </span>
                  <span className="text-[9px] font-mono uppercase bg-stone-950 text-stone-300 px-2 py-0.5 border border-stone-800">
                    {preset.config.paint.name}
                  </span>
                </div>
              </div>

              <button
                onClick={() => {
                  onSelectPreset(preset.config);
                  const el = document.getElementById('workbench-viewport');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                id={`btn-load-preset-${preset.id}`}
                className="w-full py-2.5 bg-stone-950 group-hover:bg-orange-600 border border-stone-800 group-hover:border-orange-500 text-stone-100 text-xs font-mono uppercase tracking-wider font-bold transition-all duration-300 flex items-center justify-center space-x-2"
              >
                <span>LOAD TO WORKBENCH</span>
                <ArrowUpRight size={12} />
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
