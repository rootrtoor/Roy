import { Hammer, Settings, ClipboardList, Milestone } from 'lucide-react';

export default function ProcessTimeline() {
  const steps = [
    {
      num: '01',
      title: 'COMMISSION INTAKE',
      icon: <ClipboardList size={18} className="text-orange-500" />,
      desc: 'We review your custom workbench setup. A direct lead builder reviews frame dimensions, clearances, and validates paint tolerances. We draft structural schematics.',
    },
    {
      num: '02',
      title: 'TIG-WELD CHASSIS',
      icon: <Hammer size={18} className="text-orange-500" />,
      desc: 'Our frames are hand-assembled using premium 4130 Chromoly steel. Motor brackets are custom milled and heavy-gauge reinforced to handle engine vibration harmonics.',
    },
    {
      num: '03',
      title: 'POWERPLANT TUNING',
      icon: <Settings size={18} className="text-orange-500" />,
      desc: 'Two-strokes have their cranks balanced and ports polished. Four-strokes receive high-performance valve lash adjustments. Electric systems have custom thermal management applied.',
    },
    {
      num: '04',
      title: 'SHAKEDOWN RUNS',
      icon: <Milestone size={18} className="text-orange-500" />,
      desc: 'Every bicycle undergoes a rigorous 50-mile road run on Austin roadways to verify compression, chain alignment, brake response, and electrical conductivity.',
    },
  ];

  return (
    <div className="bg-stone-900 border-t border-stone-800 p-8 md:p-12 relative overflow-hidden">
      {/* Background Graphic Accent */}
      <div className="absolute right-0 bottom-0 opacity-5 text-stone-500 font-black text-9xl transform translate-x-1/4 translate-y-1/4 select-none pointer-events-none">
        ATX WELDED
      </div>

      <div className="max-w-7xl mx-auto">
        <div className="mb-10 text-center md:text-left">
          <span className="text-[10px] font-bold text-orange-600 uppercase tracking-widest block mb-2">
            CRAFTED WITH INTENT
          </span>
          <h2 className="text-3xl font-black uppercase tracking-tighter text-stone-100">
            THE CHRONICLED BUILD PROCESS
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 relative">
          {/* Connecting line on desktop */}
          <div className="hidden md:block absolute top-14 left-8 right-8 h-[1px] bg-stone-800 z-0" />

          {steps.map((step, idx) => (
            <div
              key={step.num}
              className="bg-stone-950 p-6 border border-stone-800 relative z-10 flex flex-col justify-between"
            >
              <div>
                <div className="flex justify-between items-center mb-6">
                  <div className="w-10 h-10 bg-stone-900 border border-stone-800 flex items-center justify-center font-bold text-sm text-stone-300 font-mono">
                    {step.num}
                  </div>
                  <div className="p-2 bg-stone-900/40 border border-stone-800/80">
                    {step.icon}
                  </div>
                </div>

                <h3 className="text-sm font-black text-white uppercase tracking-wider mb-3">
                  {step.title}
                </h3>
                
                <p className="text-xs text-stone-400 font-light leading-relaxed">
                  {step.desc}
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-stone-900 text-[9px] font-mono text-stone-500">
                STAGE {idx + 1} COMPLETE CERTIFIED
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
