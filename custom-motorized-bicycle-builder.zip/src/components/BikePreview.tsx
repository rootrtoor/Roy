import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { BikeConfig } from '../types';
import { Play, Square, Volume2, VolumeX } from 'lucide-react';

interface BikePreviewProps {
  config: BikeConfig;
  isEngineRunning: boolean;
  setIsEngineRunning: (running: boolean) => void;
  isRevving: boolean;
  setIsRevving: (revving: boolean) => void;
}

export default function BikePreview({
  config,
  isEngineRunning,
  setIsEngineRunning,
  isRevving,
  setIsRevving,
}: BikePreviewProps) {
  const [audioSupported, setAudioSupported] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const oscillatorRef = useRef<OscillatorNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const lfoRef = useRef<OscillatorNode | null>(null);
  const lfoGainRef = useRef<GainNode | null>(null);

  // Initialize Audio Context on user gesture
  const startEngineSound = () => {
    if (isEngineRunning) {
      stopEngineSound();
      return;
    }

    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }

      // Create primary oscillator for engine ignition
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      oscillatorRef.current = osc;
      gainNodeRef.current = gain;

      // Configure based on engine type
      if (config.engine.type === '2-stroke') {
        // Raw, raspy sawtooth sound
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(config.engine.soundFrequency, ctx.currentTime);
        
        // Use an LFO to create the "pop-pop-pop" sputtering of a 2-stroke
        const lfo = ctx.createOscillator();
        const lfoGain = ctx.createGain();
        lfo.type = 'sawtooth';
        lfo.frequency.value = 14; // sputtering rate
        lfoGain.gain.value = 25; // sputter amplitude pitch drift
        
        lfo.connect(lfoGain);
        lfoGain.connect(osc.frequency);
        lfo.start();
        lfoRef.current = lfo;
        lfoGainRef.current = lfoGain;

        // Base volume
        gain.gain.setValueAtTime(isMuted ? 0 : 0.08, ctx.currentTime);
      } else if (config.engine.type === '4-stroke') {
        // Deep thumping sound
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(config.engine.soundFrequency, ctx.currentTime);
        
        const lfo = ctx.createOscillator();
        const lfoGain = ctx.createGain();
        lfo.type = 'square';
        lfo.frequency.value = 8; // slower chug
        lfoGain.gain.value = 12;
        
        lfo.connect(lfoGain);
        lfoGain.connect(osc.frequency);
        lfo.start();
        lfoRef.current = lfo;
        lfoGainRef.current = lfoGain;

        gain.gain.setValueAtTime(isMuted ? 0 : 0.15, ctx.currentTime);
      } else {
        // Electric whistle (sine wave)
        osc.type = 'sine';
        osc.frequency.setValueAtTime(80, ctx.currentTime); // very low hum at idle
        gain.gain.setValueAtTime(isMuted ? 0 : 0.01, ctx.currentTime);
      }

      // Lowpass filter to make it sound muffled and mechanical
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(config.engine.type === 'electric' ? 1200 : 450, ctx.currentTime);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      setIsEngineRunning(true);
    } catch (e) {
      console.error('Web Audio API not fully supported or blocked:', e);
      setAudioSupported(false);
      setIsEngineRunning(true); // fall back to silent visual shaking
    }
  };

  const stopEngineSound = () => {
    try {
      if (oscillatorRef.current) {
        oscillatorRef.current.stop();
        oscillatorRef.current.disconnect();
        oscillatorRef.current = null;
      }
      if (lfoRef.current) {
        lfoRef.current.stop();
        lfoRef.current.disconnect();
        lfoRef.current = null;
      }
      if (gainNodeRef.current) {
        gainNodeRef.current.disconnect();
        gainNodeRef.current = null;
      }
    } catch (e) {
      console.error(e);
    }
    setIsEngineRunning(false);
    setIsRevving(false);
  };

  // Rev engine effect (raising pitch and gain)
  useEffect(() => {
    if (!isEngineRunning || !oscillatorRef.current || !audioCtxRef.current) return;
    
    const ctx = audioCtxRef.current;
    const osc = oscillatorRef.current;
    const gain = gainNodeRef.current;
    const lfo = lfoRef.current;
    const lfoGain = lfoGainRef.current;

    const targetFreq = isRevving 
      ? config.engine.soundFrequency * (config.engine.type === 'electric' ? 3.5 : 2.2) 
      : config.engine.soundFrequency;

    const targetVol = isRevving
      ? (config.engine.type === 'electric' ? 0.09 : 0.18)
      : (config.engine.type === 'electric' ? 0.01 : (config.engine.type === '4-stroke' ? 0.15 : 0.08));

    if (gain && !isMuted) {
      gain.gain.linearRampToValueAtTime(targetVol, ctx.currentTime + 0.15);
    }

    if (osc) {
      osc.frequency.exponentialRampToValueAtTime(targetFreq, ctx.currentTime + 0.2);
    }

    if (lfo && lfoGain) {
      // Sputter rate increases when revving
      lfo.frequency.setValueAtTime(isRevving ? 25 : (config.engine.type === '2-stroke' ? 14 : 8), ctx.currentTime);
      lfoGain.gain.setValueAtTime(isRevving ? 45 : (config.engine.type === '2-stroke' ? 25 : 12), ctx.currentTime);
    }
  }, [isRevving, isEngineRunning, config.engine, isMuted]);

  // Handle changing engines while running
  useEffect(() => {
    if (isEngineRunning) {
      stopEngineSound();
    }
  }, [config.engine]);

  // Handle mute toggles
  useEffect(() => {
    if (gainNodeRef.current && audioCtxRef.current) {
      const vol = isMuted ? 0 : (isRevving ? 0.18 : 0.08);
      gainNodeRef.current.gain.setValueAtTime(vol, audioCtxRef.current.currentTime);
    }
  }, [isMuted]);

  // Clean up audio context on unmount
  useEffect(() => {
    return () => {
      if (oscillatorRef.current) {
        try {
          oscillatorRef.current.stop();
        } catch (_) {}
      }
    };
  }, []);

  // Bike frame visual structures based on selection
  const isBoardTrack = config.frame.style === 'board-track';
  const isCruiser = config.frame.style === 'cruiser';
  const isCafeRacer = config.frame.style === 'cafe-racer';

  // Accessories checks
  const hasSpringer = config.accessories.includes('springer-fork');
  const hasHeadlight = config.accessories.includes('brass-headlight');
  const hasPannier = config.accessories.includes('leather-pannier');
  const hasExhaust = config.accessories.includes('exhaust-chamber') && config.engine.type !== 'electric';
  const hasSpringSeat = config.accessories.includes('dual-spring-seat');

  // Paint setup
  const primaryColor = config.paint.hex;
  const isRaw = config.paint.type === 'raw';

  return (
    <div className="flex flex-col h-full justify-between p-6 md:p-8 bg-stone-900 border border-stone-800 relative group overflow-hidden">
      {/* Background Grid Pattern */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1c1917_1px,transparent_1px),linear-gradient(to_bottom,#1c1917_1px,transparent_1px)] bg-[size:24px_24px] opacity-40 pointer-events-none" />

      {/* Radiant glow on engine running */}
      <AnimatePresence>
        {isEngineRunning && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: isRevving ? 0.35 : 0.15 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-orange-500 via-transparent to-transparent pointer-events-none transition-all duration-300"
          />
        )}
      </AnimatePresence>

      {/* Meta Specifications Overlay */}
      <div className="flex justify-between items-start z-10">
        <div>
          <span className="inline-block bg-orange-600 text-[10px] px-2.5 py-1 font-bold uppercase tracking-[0.2em] mb-2">
            ACTIVE PREVIEW
          </span>
          <h3 className="text-xl font-black uppercase tracking-tight text-white font-sans">
            CUSTOM {config.frame.name}
          </h3>
          <p className="text-xs text-stone-400 font-mono">
            PAINT: <span style={{ color: primaryColor }} className="font-bold uppercase">{config.paint.name}</span>
          </p>
        </div>

        {/* Audio Engine Interface */}
        <div className="flex items-center space-x-2">
          {isEngineRunning && (
            <button
              onClick={() => setIsMuted(!isMuted)}
              id="btn-mute"
              className="p-2 border border-stone-800 bg-stone-950 text-stone-400 hover:text-white transition-colors"
              title={isMuted ? "Unmute Engine" : "Mute Engine"}
            >
              {isMuted ? <VolumeX size={14} /> : <Volume2 size={14} />}
            </button>
          )}

          <button
            onClick={startEngineSound}
            id="btn-start-engine"
            className={`px-4 py-1.5 flex items-center space-x-2 border text-[11px] font-mono uppercase tracking-wider transition-all duration-300 ${
              isEngineRunning
                ? 'border-orange-500 bg-orange-600 text-white hover:bg-orange-700 font-bold animate-pulse'
                : 'border-stone-700 bg-stone-950 text-stone-300 hover:border-stone-500'
            }`}
          >
            {isEngineRunning ? (
              <>
                <Square size={11} className="fill-white" />
                <span>KILL SWITCH</span>
              </>
            ) : (
              <>
                <Play size={11} className="fill-stone-300" />
                <span>START ENGINE</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Bicycle Vector SVG Stage */}
      <div className="flex-1 flex items-center justify-center relative my-4 min-h-[220px] md:min-h-[280px]">
        <svg
          id="svg-bike-customizer"
          viewBox="0 0 600 350"
          className="w-full max-w-[500px] h-auto drop-shadow-[0_10px_15px_rgba(0,0,0,0.6)]"
        >
          {/* DEFINITIONS AND GRADIENTS */}
          <defs>
            <radialGradient id="tireGrad" cx="50%" cy="50%" r="50%">
              <stop offset="70%" stopColor="#1c1917" />
              <stop offset="90%" stopColor="#0c0a09" />
              <stop offset="100%" stopColor="#292524" />
            </radialGradient>
            <linearGradient id="metallicGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor={primaryColor} />
              <stop offset="50%" stopColor="#ffffff" stopOpacity={0.3} />
              <stop offset="100%" stopColor={primaryColor} />
            </linearGradient>
            <linearGradient id="chromeGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#d6d3d1" />
              <stop offset="50%" stopColor="#ffffff" />
              <stop offset="100%" stopColor="#78716c" />
            </linearGradient>
            <linearGradient id="brassGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#ca8a04" />
              <stop offset="60%" stopColor="#fef08a" />
              <stop offset="100%" stopColor="#854d0e" />
            </linearGradient>
            <filter id="glow">
              <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
              <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
          </defs>

          {/* GROUND LINE */}
          <line x1="40" y1="282" x2="560" y2="282" stroke="#292524" strokeWidth="2" strokeDasharray="6 4" />

          {/* REAR WHEEL GROUP (Rotates if engine running) */}
          <g id="rear-wheel" transform="translate(140, 220)">
            <motion.g
              animate={isEngineRunning ? { rotate: isRevving ? 1080 : 360 } : {}}
              transition={{ repeat: Infinity, duration: isRevving ? 1.5 : 4, ease: 'linear' }}
            >
              {/* Tire (Black / White-Wall / Knobby) */}
              <circle cx="0" cy="0" r="62" fill="none" stroke="#1c1917" strokeWidth="12" />
              {config.tire.style === 'white-wall' && (
                <circle cx="0" cy="0" r="54" fill="none" stroke="#f5f5f4" strokeWidth="5" />
              )}
              {config.tire.style === 'knobby' && (
                <circle cx="0" cy="0" r="62" fill="none" stroke="#292524" strokeWidth="12" strokeDasharray="4 6" />
              )}
              {/* Inner Rim */}
              <circle cx="0" cy="0" r="49" fill="none" stroke="#57534e" strokeWidth="2.5" />
              {/* Hub Spokes */}
              {Array.from({ length: 18 }).map((_, i) => (
                <line
                  key={i}
                  x1="0"
                  y1="0"
                  x2={Math.cos((i * Math.PI) / 9) * 48}
                  y2={Math.sin((i * Math.PI) / 9) * 48}
                  stroke="#78716c"
                  strokeWidth="0.8"
                />
              ))}
              {/* Center Axle / Sprocket */}
              <circle cx="0" cy="0" r="14" fill="#292524" stroke="#44403c" strokeWidth="2" />
              <circle cx="0" cy="0" r="8" fill="#a8a29e" />
            </motion.g>
          </g>

          {/* FRONT WHEEL GROUP */}
          <g id="front-wheel" transform="translate(460, 220)">
            <motion.g
              animate={isEngineRunning ? { rotate: isRevving ? 1080 : 360 } : {}}
              transition={{ repeat: Infinity, duration: isRevving ? 1.5 : 4, ease: 'linear' }}
            >
              {/* Tire */}
              <circle cx="0" cy="0" r="62" fill="none" stroke="#1c1917" strokeWidth="12" />
              {config.tire.style === 'white-wall' && (
                <circle cx="0" cy="0" r="54" fill="none" stroke="#f5f5f4" strokeWidth="5" />
              )}
              {config.tire.style === 'knobby' && (
                <circle cx="0" cy="0" r="62" fill="none" stroke="#292524" strokeWidth="12" strokeDasharray="4 6" />
              )}
              {/* Inner Rim */}
              <circle cx="0" cy="0" r="49" fill="none" stroke="#57534e" strokeWidth="2.5" />
              {/* Spokes */}
              {Array.from({ length: 18 }).map((_, i) => (
                <line
                  key={i}
                  x1="0"
                  y1="0"
                  x2={Math.cos((i * Math.PI) / 9) * 48}
                  y2={Math.sin((i * Math.PI) / 9) * 48}
                  stroke="#78716c"
                  strokeWidth="0.8"
                />
              ))}
              {/* Front Hub */}
              <circle cx="0" cy="0" r="7" fill="#78716c" />
            </motion.g>
          </g>

          {/* DRIVE CHAIN (Runs from bottom bracket to rear wheel sprocket) */}
          <line x1="280" y1="220" x2="140" y2="220" stroke="#78716c" strokeWidth="3" strokeDasharray="3 2" />
          <line x1="280" y1="228" x2="140" y2="222" stroke="#44403c" strokeWidth="1.5" />

          {/* MOTORIZED DRIVE CHAIN (Engine sprocket to rear wheel sprocket - only for gas) */}
          {config.engine.type !== 'electric' && (
            <path
              d="M 265 190 L 140 215 M 265 198 L 140 223"
              stroke="#ca8a04"
              strokeWidth="2.5"
              strokeDasharray="4 2"
              className={isEngineRunning ? 'animate-[dash_0.5s_linear_infinite]' : ''}
              style={{
                animationDuration: isRevving ? '0.1s' : '0.4s',
              }}
            />
          )}

          {/* BIKE FRAME - STATIC GEOMETRY COORDS */}
          {/* Main frame lines mapped beautifully */}
          <g id="frame-structure" strokeLinecap="round" strokeLinejoin="round">
            {/* Chain Stay */}
            <line x1="140" y1="220" x2="280" y2="220" stroke="#1c1917" strokeWidth="6" />
            <line x1="140" y1="220" x2="280" y2="220" stroke={config.paint.type === 'metallic' ? 'url(#metallicGrad)' : primaryColor} strokeWidth="4" />

            {/* Seat Stay */}
            <line x1="140" y1="220" x2="240" y2="120" stroke="#1c1917" strokeWidth="6" />
            <line x1="140" y1="220" x2="240" y2="120" stroke={config.paint.type === 'metallic' ? 'url(#metallicGrad)' : primaryColor} strokeWidth="4" />

            {/* Down Tube */}
            <line x1="280" y1="220" x2="410" y2="90" stroke="#1c1917" strokeWidth="8" />
            <line x1="280" y1="220" x2="410" y2="90" stroke={config.paint.type === 'metallic' ? 'url(#metallicGrad)' : primaryColor} strokeWidth="5.5" />

            {/* Seat Tube */}
            <line x1="280" y1="220" x2="240" y2="120" stroke="#1c1917" strokeWidth="8" />
            <line x1="280" y1="220" x2="240" y2="120" stroke={config.paint.type === 'metallic' ? 'url(#metallicGrad)' : primaryColor} strokeWidth="5.5" />

            {/* Dynamic Custom Top Tube depending on styling */}
            {isBoardTrack && (
              <>
                {/* Curved drop loop frame tube for board track vintage tank alignment */}
                <path
                  d="M 240 120 Q 320 145 410 90"
                  fill="none"
                  stroke="#1c1917"
                  strokeWidth="8"
                />
                <path
                  d="M 240 120 Q 320 145 410 90"
                  fill="none"
                  stroke={config.paint.type === 'metallic' ? 'url(#metallicGrad)' : primaryColor}
                  strokeWidth="5.5"
                />
                <path
                  d="M 240 120 Q 320 190 410 90"
                  fill="none"
                  stroke="#1c1917"
                  strokeWidth="6"
                />
                <path
                  d="M 240 120 Q 320 190 410 90"
                  fill="none"
                  stroke={config.paint.type === 'metallic' ? 'url(#metallicGrad)' : primaryColor}
                  strokeWidth="4"
                />
              </>
            )}

            {isCruiser && (
              <>
                {/* Elegant twin-arch tubes */}
                <path
                  d="M 240 120 C 300 90, 360 90, 410 90"
                  fill="none"
                  stroke="#1c1917"
                  strokeWidth="7"
                />
                <path
                  d="M 240 120 C 300 90, 360 90, 410 90"
                  fill="none"
                  stroke={config.paint.type === 'metallic' ? 'url(#metallicGrad)' : primaryColor}
                  strokeWidth="4.5"
                />
                <path
                  d="M 240 135 C 300 115, 360 115, 410 90"
                  fill="none"
                  stroke="#1c1917"
                  strokeWidth="5"
                />
                <path
                  d="M 240 135 C 300 115, 360 115, 410 90"
                  fill="none"
                  stroke={config.paint.type === 'metallic' ? 'url(#metallicGrad)' : primaryColor}
                  strokeWidth="3"
                />
              </>
            )}

            {isCafeRacer && (
              <>
                {/* Bold straight vintage racer bars style */}
                <line x1="240" y1="120" x2="410" y2="90" stroke="#1c1917" strokeWidth="9" />
                <line x1="240" y1="120" x2="410" y2="90" stroke={config.paint.type === 'metallic' ? 'url(#metallicGrad)' : primaryColor} strokeWidth="6.5" />
                
                {/* Additional bracing tube */}
                <line x1="240" y1="145" x2="350" y2="145" stroke="#1c1917" strokeWidth="5.5" />
                <line x1="240" y1="145" x2="350" y2="145" stroke={config.paint.type === 'metallic' ? 'url(#metallicGrad)' : primaryColor} strokeWidth="3.5" />
              </>
            )}
          </g>

          {/* GAS TANK (Mounts on top tube) */}
          <g id="gas-tank" transform="translate(265, 88)">
            {/* Base Black outlines */}
            {isBoardTrack && (
              <path
                d="M 10 32 C 40 45, 100 45, 125 0 C 80 -8, 30 10, 10 32 Z"
                fill="#292524"
                stroke="#1c1917"
                strokeWidth="2"
              />
            )}
            {isCruiser && (
              <path
                d="M 5 18 C 35 22, 95 18, 125 0 C 80 -10, 25 -5, 5 18 Z"
                fill="#292524"
                stroke="#1c1917"
                strokeWidth="2"
              />
            )}
            {isCafeRacer && (
              <path
                d="M 0 32 L 130 5 C 110 -15, 40 -15, 0 32 Z"
                fill="#1c1917"
                stroke="#0c0a09"
                strokeWidth="2.5"
              />
            )}

            {/* Custom Tank Plate painted to match or leather details */}
            <path
              d={isBoardTrack 
                ? "M 15 30 C 42 40, 95 40, 120 5 C 80 -4, 35 12, 15 30 Z"
                : isCruiser
                ? "M 10 16 C 38 19, 90 16, 120 3 C 80 -6, 30 -2, 10 16 Z"
                : "M 5 28 L 122 5 C 105 -10, 42 -10, 5 28 Z"
              }
              fill={config.paint.type === 'metallic' ? 'url(#metallicGrad)' : primaryColor}
            />

            {/* Tank decal "AXEL & CHAIN" */}
            <text
              x="60"
              y={isCafeRacer ? "12" : "22"}
              fill="#ffffff"
              fontSize="6"
              fontWeight="900"
              fontFamily="monospace"
              letterSpacing="1"
              textAnchor="middle"
              opacity="0.85"
            >
              A&C
            </text>

            {/* Gas Cap */}
            <circle cx="95" cy="0" r="4" fill="url(#chromeGrad)" stroke="#1c1917" strokeWidth="1" />
          </g>

          {/* ENGINE GROUP (Vibrates if engine is started) */}
          <motion.g
            id="engine-unit"
            animate={isEngineRunning ? {
              x: isRevving ? [0, -1.8, 1.8, -1.2, 1.2, 0] : [0, -0.6, 0.6, -0.6, 0],
              y: isRevving ? [0, 1.2, -1.2, 1.2, -1.2, 0] : [0, 0.5, -0.5, 0.5, 0]
            } : {}}
            transition={{
              repeat: Infinity,
              duration: isRevving ? 0.08 : 0.15,
              ease: 'linear'
            }}
          >
            {/* 2-STROKE ENGINE ILLUSTRATION */}
            {config.engine.type === '2-stroke' && (
              <g transform="translate(280, 195)">
                {/* Engine Mounting Plate */}
                <rect x="-15" y="-5" width="30" height="25" fill="#44403c" rx="2" />
                
                {/* Crank Case */}
                <circle cx="0" cy="15" r="18" fill="url(#chromeGrad)" stroke="#292524" strokeWidth="1.5" />
                <circle cx="0" cy="15" r="8" fill="#57534e" />
                
                {/* Slanted Cylinder Head (Heat Fins) */}
                <g transform="rotate(-15)">
                  {/* Cylinder block */}
                  <rect x="-10" y="-22" width="20" height="24" fill="#57534e" rx="1" />
                  {/* Cooling Fins */}
                  <line x1="-16" y1="-18" x2="16" y2="-18" stroke="#1c1917" strokeWidth="2.5" />
                  <line x1="-18" y1="-13" x2="18" y2="-13" stroke="#1c1917" strokeWidth="2.5" />
                  <line x1="-18" y1="-8" x2="18" y2="-8" stroke="#1c1917" strokeWidth="2.5" />
                  <line x1="-16" y1="-3" x2="16" y2="-3" stroke="#1c1917" strokeWidth="2.5" />
                  {/* Cylinder Head Cap */}
                  <path d="M -12 -22 L 12 -22 L 8 -30 L -8 -30 Z" fill="url(#chromeGrad)" stroke="#1c1917" />
                  {/* Spark Plug Wire */}
                  <circle cx="0" cy="-31" r="3" fill="#dc2626" />
                  <path d="M 0 -31 Q -22 -35 -15 -10" fill="none" stroke="#dc2626" strokeWidth="1.5" />
                </g>

                {/* Carburetor & Air Filter */}
                <rect x="-24" y="-2" width="10" height="8" fill="#78716c" />
                <circle cx="-29" cy="2" r="6" fill="#1c1917" />

                {/* Performance Chrome Exhaust Extension */}
                {hasExhaust && (
                  <path
                    d="M 5 -10 Q 30 -5 32 30 Q 34 65 -45 55"
                    fill="none"
                    stroke="url(#chromeGrad)"
                    strokeWidth="4.5"
                    strokeLinecap="round"
                  />
                )}
              </g>
            )}

            {/* 4-STROKE ENGINE ILLUSTRATION */}
            {config.engine.type === '4-stroke' && (
              <g transform="translate(280, 195)">
                {/* Crank Case Base Block */}
                <rect x="-20" y="2" width="40" height="20" fill="url(#chromeGrad)" stroke="#292524" rx="3" strokeWidth="1.5" />
                <circle cx="-6" cy="12" r="6" fill="#57534e" />

                {/* Upright Cylinder Cylinder */}
                <rect x="-12" y="-24" width="24" height="26" fill="#44403c" />
                {/* Horizontal Fins */}
                <line x1="-17" y1="-20" x2="17" y2="-20" stroke="#1c1917" strokeWidth="3" />
                <line x1="-17" y1="-14" x2="17" y2="-14" stroke="#1c1917" strokeWidth="3" />
                <line x1="-17" y1="-8" x2="17" y2="-8" stroke="#1c1917" strokeWidth="3" />
                
                {/* OHV Overhead Valve Cover */}
                <rect x="-14" y="-31" width="28" height="8" fill="url(#chromeGrad)" rx="2" stroke="#1c1917" />
                
                {/* Spark Wire & Pull Starter case */}
                <circle cx="15" cy="12" r="10" fill="#292524" />
                <path d="M -8 -28 Q -28 -28 -20 8" fill="none" stroke="#2563eb" strokeWidth="1.5" />
              </g>
            )}

            {/* ELECTRIC STEALTH SYSTEM */}
            {config.engine.type === 'electric' && (
              <g>
                {/* Custom Fitted Leather Battery Cover inside Frame Triangle */}
                <path
                  d="M 245 130 Q 320 185 400 102 L 285 210 Z"
                  fill="#78350f"
                  stroke="#451a03"
                  strokeWidth="2.5"
                />
                {/* Brass Rivets on Leather Casing */}
                <circle cx="265" cy="148" r="1.5" fill="url(#brassGrad)" />
                <circle cx="300" cy="170" r="1.5" fill="url(#brassGrad)" />
                <circle cx="340" cy="160" r="1.5" fill="url(#brassGrad)" />
                <circle cx="370" cy="130" r="1.5" fill="url(#brassGrad)" />
                
                {/* Electric Hub Motor inside Rear Wheel */}
                <circle cx="140" cy="220" r="32" fill="#1c1917" stroke="#44403c" strokeWidth="2" />
                {/* Electric wiring line to battery */}
                <path d="M 140 220 Q 210 230 265 212" fill="none" stroke="#1c1917" strokeWidth="2" strokeDasharray="2 2" />
              </g>
            )}
          </motion.g>

          {/* EXHAUST FUMES (Visually emits if engine is running and is gas-powered) */}
          <AnimatePresence>
            {isEngineRunning && config.engine.type !== 'electric' && (
              <g id="exhaust-smoke">
                {/* Fumes location depending on accessories / default engine exhaust outlet */}
                {Array.from({ length: 4 }).map((_, i) => (
                  <motion.circle
                    key={i}
                    cx={hasExhaust ? 95 : 295}
                    cy={hasExhaust ? 250 : 225}
                    r={2}
                    fill="#a8a29e"
                    initial={{ opacity: 0.6, scale: 0.5, x: 0, y: 0 }}
                    animate={{
                      opacity: 0,
                      scale: isRevving ? 5.5 : 3.5,
                      x: isRevving ? -60 - (i * 15) : -35 - (i * 10),
                      y: isRevving ? -10 + (Math.sin(i) * 12) : -5 + (Math.sin(i) * 6)
                    }}
                    transition={{
                      repeat: Infinity,
                      duration: isRevving ? 0.35 + (i * 0.1) : 0.7 + (i * 0.15),
                      delay: i * 0.15,
                      ease: 'easeOut'
                    }}
                  />
                ))}
              </g>
            )}
          </AnimatePresence>

          {/* SADDLE / SEAT POST */}
          <g id="seat-post" transform="translate(240, 120)">
            <line x1="0" y1="0" x2="-5" y2="-20" stroke="#44403c" strokeWidth="5.5" />
            
            {/* Leather dual spring seat saddle */}
            {hasSpringSeat ? (
              <g transform="translate(-15, -28)">
                {/* Heavy springs */}
                <circle cx="5" cy="8" r="4" fill="none" stroke="url(#chromeGrad)" strokeWidth="2" />
                <circle cx="15" cy="8" r="4" fill="none" stroke="url(#chromeGrad)" strokeWidth="2" />
                {/* Leather Saddle Body */}
                <path d="M -6 0 C 10 -4, 25 -4, 32 0 C 28 8, 15 10, -6 6 Z" fill="#78350f" stroke="#451a03" />
                <path d="M -6 0 L -12 6 C -8 10, -3 8, -6 0" fill="#78350f" />
              </g>
            ) : (
              // Simple vintage streamlined saddle
              <g transform="translate(-12, -24)">
                <rect x="0" y="0" width="24" height="6" fill="#1c1917" rx="2" />
                <path d="M 0 0 C -8 2, -10 6, -10 10 C -3 8, 0 2, 0 0" fill="#1c1917" />
              </g>
            )}
          </g>

          {/* FRONT FORK & HANDLEBARS */}
          <g id="steering-assembly" transform="translate(410, 90)">
            {/* Main steering tube */}
            <line x1="0" y1="0" x2="50" y2="130" stroke="#1c1917" strokeWidth="7" />
            <line x1="0" y1="0" x2="50" y2="130" stroke={config.paint.type === 'metallic' ? 'url(#metallicGrad)' : primaryColor} strokeWidth="4.5" />

            {/* SPRINGER SUSPENSION FORK ACCESSORY */}
            {hasSpringer && (
              <g strokeLinecap="round">
                {/* Secondary parallel truss fork */}
                <line x1="-10" y1="5" x2="40" y2="130" stroke="url(#chromeGrad)" strokeWidth="3" />
                {/* Heavy coil springs at the top headset */}
                <rect x="-11" y="-5" width="8" height="15" fill="#a8a29e" stroke="#57534e" rx="1.5" />
                <line x1="-7" y1="-5" x2="-7" y2="10" stroke="#1c1917" strokeWidth="2.5" strokeDasharray="1.5 1.5" />
              </g>
            )}

            {/* Handlebar Stem */}
            <line x1="0" y1="0" x2="-6" y2="-12" stroke="url(#chromeGrad)" strokeWidth="4.5" />

            {/* DYNAMIC HANDLEBAR STYLES */}
            {isBoardTrack && (
              // Dropped, curved board track racing bars
              <path
                d="M -6 -12 Q -22 -12 -30 2 Q -35 15 -18 16"
                fill="none"
                stroke="#1c1917"
                strokeWidth="3.5"
                strokeLinecap="round"
              />
            )}
            {isCruiser && (
              // High, swept back cruiser bars
              <path
                d="M -6 -12 Q -12 -28 -30 -22"
                fill="none"
                stroke="#1c1917"
                strokeWidth="3.5"
                strokeLinecap="round"
              />
            )}
            {isCafeRacer && (
              // Low flat clip-on/clubman cafe racer bars
              <path
                d="M -6 -12 L -28 -14 L -24 -4"
                fill="none"
                stroke="#1c1917"
                strokeWidth="3.5"
                strokeLinecap="round"
              />
            )}

            {/* Leather Wrapped Grips */}
            <rect x="-24" y="10" width="8" height="4.5" transform="rotate(10 -24 10)" fill="#78350f" rx="1" />

            {/* BRASS HEADLIGHT ACCESSORY (Glows when running) */}
            {hasHeadlight && (
              <g transform="translate(10, 30)">
                {/* Bracket */}
                <line x1="-12" y1="0" x2="0" y2="5" stroke="#44403c" strokeWidth="2.5" />
                {/* Brass Housing */}
                <path d="M 0 -10 C 10 -10, 14 -5, 14 5 C 14 15, 10 20, 0 20 C -4 10, -4 -10, 0 -10 Z" fill="url(#brassGrad)" stroke="#78350f" />
                {/* Front lens glass cover */}
                <path d="M 10 -6 Q 13 5 10 16 Z" fill="#e0f2fe" opacity="0.6" />
                
                {/* Illuminated yellow projection glow when running */}
                {isEngineRunning && (
                  <path
                    d="M 12 0 L 120 -35 L 120 55 Z"
                    fill="url(#brassGrad)"
                    opacity="0.25"
                    filter="url(#glow)"
                    className="pointer-events-none"
                  />
                )}
              </g>
            )}
          </g>

          {/* LEATHER PANNIER BAG (REAR) */}
          {hasPannier && (
            <g transform="translate(110, 160)">
              {/* Oiled brown leather bag body */}
              <rect x="0" y="0" width="35" height="28" fill="#78350f" stroke="#451a03" rx="4" strokeWidth="1.5" />
              {/* Top envelope flap */}
              <path d="M -2 0 L 37 0 L 30 12 L 5 12 Z" fill="#451a03" />
              {/* Closing straps */}
              <line x1="8" y1="12" x2="8" y2="24" stroke="#1c1917" strokeWidth="2" />
              <line x1="26" y1="12" x2="26" y2="24" stroke="#1c1917" strokeWidth="2" />
              {/* Tiny metal brass buckles */}
              <circle cx="8" cy="14" r="1.5" fill="url(#brassGrad)" />
              <circle cx="26" cy="14" r="1.5" fill="url(#brassGrad)" />
            </g>
          )}

          {/* Bottom bracket chain-ring/pedals */}
          <g transform="translate(280, 220)">
            <circle cx="0" cy="0" r="14" fill="url(#chromeGrad)" stroke="#44403c" strokeWidth="1" />
            <circle cx="0" cy="0" r="6" fill="#1c1917" />
            {/* Spinning pedal arm if engine running */}
            <motion.g
              animate={isEngineRunning ? { rotate: isRevving ? 720 : 180 } : {}}
              transition={{ repeat: Infinity, duration: isRevving ? 2 : 5, ease: 'linear' }}
            >
              <line x1="0" y1="0" x2="0" y2="-22" stroke="url(#chromeGrad)" strokeWidth="3.5" strokeLinecap="round" />
              <rect x="-6" y="-26" width="12" height="4.5" fill="#1c1917" rx="1" />
              <line x1="0" y1="0" x2="0" y2="22" stroke="url(#chromeGrad)" strokeWidth="3.5" strokeLinecap="round" />
              <rect x="-6" y="21" width="12" height="4.5" fill="#1c1917" rx="1" />
            </motion.g>
          </g>
        </svg>
      </div>

      {/* Revving trigger & warning */}
      <div className="flex flex-col items-center justify-center space-y-2 z-10">
        {isEngineRunning ? (
          <div className="flex flex-col items-center space-y-1 w-full max-w-xs">
            <button
              onMouseDown={() => setIsRevving(true)}
              onMouseUp={() => setIsRevving(false)}
              onMouseLeave={() => setIsRevving(false)}
              onTouchStart={() => setIsRevving(true)}
              onTouchEnd={() => setIsRevving(false)}
              id="btn-rev-engine"
              className="w-full py-2 bg-orange-600 hover:bg-orange-700 text-stone-100 font-bold text-xs uppercase tracking-[0.2em] transition-all cursor-pointer select-none active:scale-95 flex items-center justify-center space-x-2 border border-orange-500"
            >
              <span>HOLD TO REV ENGINE</span>
            </button>
            <span className="text-[9px] text-orange-500 font-mono tracking-wider animate-pulse">
              WARNING: VIBRATIONS ENGAGED
            </span>
          </div>
        ) : (
          <div className="text-center py-2 text-stone-500 text-xs font-mono">
            ENGAGE THE START/KILL SWITCH TO HEAR MOTOR SIMULATION
          </div>
        )}
      </div>
    </div>
  );
}
