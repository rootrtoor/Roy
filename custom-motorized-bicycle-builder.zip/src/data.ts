import { FrameStyle, EngineOption, PaintOption, TireOption, AccessoryOption } from './types';

export const FRAMES: FrameStyle[] = [
  {
    id: 'board-track',
    name: 'Board Track Racer',
    description: 'Vintage 1910s racetrack profile. Low-slung drop-loop frame with iconic dropped board-track handlebars.',
    basePrice: 650,
    weight: 14,
    style: 'board-track',
  },
  {
    id: 'cruiser',
    name: 'Classic Cruiser',
    description: 'Laid-back 1950s touring ergonomics. Swept-back handlebars, spacious double-bar construction.',
    basePrice: 450,
    weight: 17,
    style: 'cruiser',
  },
  {
    id: 'cafe-racer',
    name: 'Outlaw Cafe',
    description: 'Aggressive streetfighter look. Low clubman bars, streamlined fuel-tank shroud alignment, tight geometry.',
    basePrice: 750,
    weight: 15,
    style: 'cafe-racer',
  },
];

export const ENGINES: EngineOption[] = [
  {
    id: '2-stroke-66cc',
    name: '66cc Balanced 2-Stroke',
    type: '2-stroke',
    description: 'The raw, nostalgic classic. Ported cylinder, balanced crank, runs on 40:1 gas/oil mix. Iconic raspy sound.',
    price: 550,
    topSpeed: 38,
    range: '120 MPG',
    horsepower: '3.5 HP',
    soundFrequency: 82,
  },
  {
    id: '4-stroke-49cc',
    name: '49cc OHV 4-Stroke',
    type: '4-stroke',
    description: 'Smooth, reliable, and whisper quiet. Overhead valve, separate oil sump, regular fuel. Perfect for long, clean commutes.',
    price: 680,
    topSpeed: 32,
    range: '150 MPG',
    horsepower: '2.5 HP',
    soundFrequency: 52,
  },
  {
    id: 'electric-1500w',
    name: '1.5kW Electric Hub (Stealth)',
    type: 'electric',
    description: 'Instant torque and silent acceleration. 48V Samsung cells integrated into a mock vintage fuel-tank leather case.',
    price: 950,
    topSpeed: 35,
    range: '45 Miles',
    horsepower: '2.1 HP Eq',
    soundFrequency: 180,
  },
];

export const PAINTS: PaintOption[] = [
  {
    id: 'raw-lacquer',
    name: 'Raw Steel Lacquer',
    hex: '#78716c',
    price: 120,
    type: 'raw',
  },
  {
    id: 'spitfire-orange',
    name: 'Spitfire Orange',
    hex: '#ea580c',
    price: 180,
    type: 'metallic',
  },
  {
    id: 'stealth-black',
    name: 'Stealth Black',
    hex: '#1c1917',
    price: 90,
    type: 'matte',
  },
  {
    id: 'vintage-cream',
    name: 'Vintage Cream',
    hex: '#f5f5f4',
    price: 150,
    type: 'matte',
  },
  {
    id: 'british-green',
    name: 'Racing Green',
    hex: '#14532d',
    price: 200,
    type: 'metallic',
  },
];

export const TIRES: TireOption[] = [
  {
    id: 'white-wall',
    name: 'Vintage White-Wall (2.3")',
    style: 'white-wall',
    price: 80,
  },
  {
    id: 'knobby-tracker',
    name: 'Dirt Tracker Knobby (2.4")',
    style: 'knobby',
    price: 95,
  },
  {
    id: 'thick-slick',
    name: 'Urban Street Slick (2.1")',
    style: 'thick-slick',
    price: 60,
  },
];

export const ACCESSORIES: AccessoryOption[] = [
  {
    id: 'springer-fork',
    name: 'Heavy Duty Springer Fork',
    description: 'Traditional coil suspension fork for true early-century dampening and custom stance.',
    price: 180,
    category: 'lighting',
  },
  {
    id: 'brass-headlight',
    name: 'Vintage Brass LED Headlight',
    description: 'Polished solid brass housing enclosing ultra-bright modern LED Cree chip. Rechargeable via USB.',
    price: 110,
    category: 'lighting',
  },
  {
    id: 'leather-pannier',
    name: 'Hand-Stitched Leather Side Bag',
    description: 'Brooks-grade premium oiled steerhide. Mounts to frame dropouts or rear rack.',
    price: 135,
    category: 'storage',
  },
  {
    id: 'exhaust-chamber',
    name: 'Chrome Expansion Chamber Exhaust',
    description: 'Increases engine scavenging, netting +15% torque and a deeper exhaust note. (2-stroke only)',
    price: 160,
    category: 'exhaust',
  },
  {
    id: 'dual-spring-seat',
    name: 'Brooks B135 Dual-Spring Saddle',
    description: 'Full grain leather saddle with heavy-duty chrome triple spring array. Absolute comfort.',
    price: 145,
    category: 'seat',
  },
];

// Pre-built master blueprints
export const PRESETS = [
  {
    id: 'preset-014',
    name: 'The Spitfire V3',
    serial: 'AC-2026-SPIT-14',
    description: 'Our flagship build. Low racer ergonomics, roaring 2-stroke exhaust tuning, finished in gloss orange and vintage white walls.',
    config: {
      frame: FRAMES[0], // Board Track
      engine: ENGINES[0], // 2-Stroke
      paint: PAINTS[1], // Orange
      tire: TIRES[0], // White Wall
      accessories: ['springer-fork', 'brass-headlight', 'exhaust-chamber'],
    },
  },
  {
    id: 'preset-stealth',
    name: 'The Outlaw Shadow',
    serial: 'AC-2026-SHDW-09',
    description: 'Minimalist, aggressive Cafe style. Stealth black matte coating, high torque silent electric hub, with street thick slick tires.',
    config: {
      frame: FRAMES[2], // Cafe Racer
      engine: ENGINES[2], // Electric
      paint: PAINTS[2], // Stealth Black
      tire: TIRES[2], // Thick Slick
      accessories: ['springer-fork', 'leather-pannier', 'dual-spring-seat'],
    },
  },
  {
    id: 'preset-classic',
    name: 'vintage board cruiser',
    serial: 'AC-2026-CRSR-22',
    description: 'Comfortable beach cruiser posture coupled with the supreme mileage of an overhead-valve 4-stroke engine. Finished in beautiful British Racing Green.',
    config: {
      frame: FRAMES[1], // Cruiser
      engine: ENGINES[1], // 4-stroke
      paint: PAINTS[4], // Racing Green
      tire: TIRES[0], // White Wall
      accessories: ['brass-headlight', 'dual-spring-seat'],
    },
  },
];
